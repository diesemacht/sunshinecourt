import os
import requests
import zipfile
import json
import sys

VERSION_URL = "https://github.com/diesemacht/sunshinecourt/raw/main/version.json"
ZIP_URL = "https://github.com/diesemacht/sunshinecourt/raw/main/game.zip"

def get_local_version():
    return '0.1'

def get_remote_version():
    response = requests.get(VERSION_URL)
    if response.status_code == 200:
        return response.json().get("ver")
    return None

def download_and_extract_update():
    response = requests.get(ZIP_URL)
    with open("update.zip", "wb") as file:
        file.write(response.content)
    
    with zipfile.ZipFile("update.zip", "r") as zip_ref:
        zip_ref.extractall(".")
    
    os.remove("update.zip")

def check_for_updates():
    local_version = get_local_version()
    remote_version = get_remote_version()
    
    needs_update = local_version != remote_version
    return needs_update, local_version, remote_version

def apply_update():
    download_and_extract_update()
    remote_version = get_remote_version()
    return remote_version

if __name__ == "__main__":
    command = sys.argv[1]
    if command == "check":
        print(json.dumps(check_for_updates()))
    elif command == "update":
        apply_update()
