import requests
import zipfile
import io
import os
import renpy

def get_remote_version(url):
    response = requests.get(url)
    version_info = response.json()
    return version_info["ver"]

def download_and_extract_zip(zip_url, extract_to='.'):
    response = requests.get(zip_url)
    with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
        zip_ref.extractall(extract_to)

def check_and_update_game():
    local_version = '0.1'

    remote_version_url = "https://raw.githubusercontent.com/diesemacht/sunshinecourt/main/version.json"
    remote_version = get_remote_version(remote_version_url)
    renpy.log('Check updates..')

    if local_version != remote_version:
        zip_url = "https://github.com/YourUsername/YourRepository/archive/refs/heads/main.zip"
        download_and_extract_zip(zip_url, renpy.config.gamedir)
        renpy.restart_interaction()